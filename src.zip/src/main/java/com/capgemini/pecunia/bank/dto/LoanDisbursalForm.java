package com.capgemini.pecunia.bank.dto;

public class LoanDisbursalForm {
	private String loanRequestId;
	private String option;
	
	public String getLoanRequestId() {
		return loanRequestId;
	}
	public void setLoanRequestId(String loanRequestId) {
		this.loanRequestId = loanRequestId;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	
	
	
	
}
