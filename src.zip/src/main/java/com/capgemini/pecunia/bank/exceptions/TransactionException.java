package com.capgemini.pecunia.bank.exceptions;

public class TransactionException extends Exception {

	public TransactionException(String message) {
		super(message);
	}
	 
}
