package com.capgemini.pecunia.bank.exceptions;

public class DateException extends Exception{
	
	public DateException() {
		super();
	
	}

	public DateException(String message) {
		super(message);
	
	}


}
