package com.capgemini.pecunia.bank.exceptions;

public class ValidateException extends Exception{

	public ValidateException() {
		super();
	
	}

	public ValidateException(String message) {
		super(message);
	
	}

}
