package com.capgemini.pecunia.bank.dto;

public class ErrorMessage {

	private String msg;

	public ErrorMessage(String msg) {
		super();
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
