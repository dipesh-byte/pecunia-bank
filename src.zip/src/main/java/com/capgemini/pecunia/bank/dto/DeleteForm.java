package com.capgemini.pecunia.bank.dto;

public class DeleteForm {
 
	private String accId;

	public String getAccId() {
		return accId;
	}

	public void setAccId(String accId) {
		this.accId = accId;
	}
	
	
}
