package com.capgemini.pecunia.bank.exceptions;

public class PbankTXNNotFouException extends Exception{

	public PbankTXNNotFouException() {
		super();
		
	}

	public PbankTXNNotFouException(String message) {
		super(message);
		
	}

	
}
